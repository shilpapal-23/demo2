Imports system.Data
Imports System.Data.OleDb
Partial Class Default2

    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Function acccheck(ByVal accountno As Integer) As Boolean
        Dim i As Integer
        Dim check As Boolean
        Dim dc As OleDbConnection
        Dim dcom As OleDbDataAdapter
        Dim ds As New DataSet
        dc = New OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA SOURCE=" & Server.MapPath("da.mdb;"))
        dc.Open()
        dcom = New OleDbDataAdapter("Select accno from userpass", dc)
        dcom.Fill(ds, "userpass")
        For i = 0 To ds.Tables("userpass").Rows.Count - 1
            If ds.Tables("userpass").Rows(i).Item("accno") = accountno Then
                Return True
            End If
        Next
        Return check
    End Function
    Function balance(ByVal accountno As Integer) As Integer
        Dim dc As OleDbConnection
        Dim i As Integer
        Dim val As Integer = 0
        Dim dcom As OleDbDataAdapter
        Dim ds As New DataSet
        dc = New OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA SOURCE=" & Server.MapPath("da.mdb;"))
        dc.Open()
        dcom = New OleDbDataAdapter("Select accno,amount from userpass where accno=" & accountno, dc)
        dcom.Fill(ds, "userpass")
        For i = 0 To ds.Tables("userpass").Rows.Count - 1
            If ds.Tables("userpass").Rows(i).Item("accno") = accountno Then
                val = ds.Tables("userpass").Rows(i).Item("amount")
            End If
        Next
        Return val
    End Function
    Sub updatetransferadd(ByVal accno As Integer, ByVal money As Integer)
        If (acccheck(accno)) Then
            Dim balan As Integer = balance(accno)
            Dim con As OleDbConnection
            Dim strUpdate As String
            Dim cmdUpdate As OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=Z:\e-bank\WebSite3\da.mdb")
            strUpdate = "Update userpass Set amount=" & (balan + money) & " Where accno=" & accno
            cmdUpdate = New OleDbCommand(strUpdate, con)
            con.Open()
            cmdUpdate.ExecuteNonQuery()
            con.Close()
        Else
            MsgBox("Enter the valid  Account No", MsgBoxStyle.Information, "Bank Name")
        End If
    End Sub
    Function updatetransfersub(ByVal accno As Integer, ByVal money As Integer) As Boolean
        Dim check As Boolean
        If (acccheck(accno)) Then
            Dim balan As Integer = balance(accno)
            If (balan >= money) Then

                Dim con As OleDbConnection
                Dim strUpdate As String
                Dim cmdUpdate As OleDbCommand
                con = New OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA Source=Z:\e-bank\WebSite3\da.mdb")
                strUpdate = "Update userpass Set amount=" & (balan - money) & " Where accno=" & accno
                cmdUpdate = New OleDbCommand(strUpdate, con)
                con.Open()
                cmdUpdate.ExecuteNonQuery()
                con.Close()
                check = True
            Else
                MsgBox("No Balance to transfer", MsgBoxStyle.Information, "Bank Name")
                check = False
            End If

        Else
            MsgBox("Enter the valid  Account No", MsgBoxStyle.Information, "Bank Name")
        End If
        Return check
    End Function

    Sub insertdata()
        Dim objConnection As OleDbConnection
        Dim objCmd As OleDbCommand
        Dim strConnection As String
        Dim strSQL As String
        strConnection = "PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA SOURCE=" + Server.MapPath("da.mdb;")
        objConnection = New OleDbConnection(strConnection)
        objConnection.Open()
        strSQL = "INSERT userpass set user='ravi' WHERE accno=200"
        objCmd = New OleDbCommand(strSQL, objConnection)
        objCmd.ExecuteNonQuery()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim accno As String
        accno = Request.QueryString("accno")
        If (updatetransfersub(accno, CInt(TextBox2.Text))) Then
            updatetransferadd(CInt(TextBox1.Text), CInt(TextBox2.Text))
            Response.Write("<script>alert('Transferred')</script>")
        End If
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Default4.aspx")
    End Sub


End Class