using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class Default6 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string un = Request.QueryString["user"];
        string ps = Request.QueryString["pass"];
        tin2.tin3 ty = new tin2.tin3();
        string st = ty.tinyDecrypt(ps, "0123456789");
        string u = ty.tinyDecrypt(un, "0123456789");
        int con=checkuser(u, st);
        AccessDataSource ds = new AccessDataSource();
        ds.DataFile = Server.MapPath("da.mdb");
        ds.SelectCommand  = "SELECT name,accno,amount from userpass WHERE (accno="+con+")";
        GridView1.DataSource = ds;
        GridView1.DataBind();
        
    }
    private int checkuser(string username, string password)
    {
        tin2.tin ty = new tin2.tin();
        int checks = 0;
        string unam = "'" + ty.tinyEncrypt(username, "0123456789") + "'";
        string ps = "'" + ty.tinyEncrypt(password, "0123456789") + "'";
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        OleDbConnection dcon = new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA SOURCE=" + Server.MapPath("da.mdb;"));
        OleDbDataAdapter dcom = new OleDbDataAdapter("Select accno from userpass where user=" + unam + " AND pass=" + ps, dcon);
        dcom.Fill(ds, "userpass");
        for (int i = 0; i < ds.Tables["userpass"].Rows.Count; i++)
        {
            checks = (int)(ds.Tables["userpass"].Rows[i]["accno"]);
        }
        return checks;
    }

    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    string unam = Request.QueryString["user"];
    //    string pass = Request.QueryString["pass"];
    //    Response.Redirect("Default.aspx?user=" + unam + "&" + "pass=" + pass);
    //}
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        string unam = Request.QueryString["user"];
        string pass = Request.QueryString["pass"];
        Response.Redirect("Default.aspx?user=" + unam + "&" + "pass=" + pass);
    
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
namespace tin2
{
    public class tin3
    {
        public tin3()
        {

        }
        public string tinyEncrypt(string Data, string Key)
        {
            if (Data.Length == 0)
                return string.Empty;

            uint[] keyval = uintKeygeneration(Key);

            if (Data.Length % 2 != 0)
                Data += '\0';
            byte[] dBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(Data);
            string cipher = string.Empty;
            uint[] td = new uint[2];
            for (int i = 0; i < dBytes.Length; i += 2)
            {
                td[0] = dBytes[i];
                td[1] = dBytes[i + 1];
                cipher += tinyencode(td, keyval);
            }
            return cipher;
        }
        public string tinyDecrypt(string Data, string Key)
        {
            uint[] keyval = uintKeygeneration(Key);
            int inc = 0;
            uint[] td = new uint[2];
            byte[] dBytes = new byte[Data.Length / 8 * 2];
            for (int i = 0; i < Data.Length; i += 8)
            {
                td[0] = strtouint(Data.Substring(i, 4));
                td[1] = strtouint(Data.Substring(i + 4, 4));
                tinydecode(td, keyval);
                dBytes[inc++] = (byte)td[0];
                dBytes[inc++] = (byte)td[1];
            }
            string decipheredString = System.Text.ASCIIEncoding.ASCII.GetString(dBytes, 0, dBytes.Length);
            if (decipheredString[decipheredString.Length - 1] == '\0')
                decipheredString = decipheredString.Substring(0, decipheredString.Length - 1);
            return decipheredString;

        }
        public uint[] uintKeygeneration(string Key)
        {
            uint[] formatt = new uint[4];
            if (Key.Length == 0)
                return formatt;
            Key = Key.PadRight(16, ' ').Substring(0, 16);
            int j = 0;
            for (int i = 0; i < Key.Length; i += 4)
                formatt[j++] = strtouint(Key.Substring(i, 4));
            return formatt;
        }
        private string tinyencode(uint[] dat, uint[] ke)
        {
            uint data = dat[0], data1 = dat[1], sum = 0, delta = 2654435769, n = 32;
            while (n-- > 0)
            {
                sum += delta;
                data += (data1 << 4 ^ data1 >> 5) + data1 ^ sum + ke[sum & 3];

                data1 += (data << 4 ^ data >> 5) + data ^ sum + ke[sum >> 11 & 3];

            }
            return uinttostr(data) + uinttostr(data1);
        }
        private uint strtouint(string data)
        {
            uint uin;
            uin = ((uint)data[0]) + ((uint)data[1] << 8) + ((uint)data[2] << 16) + ((uint)data[3] << 24);
            return uin;
        }
        private string uinttostr(uint data)
        {
            System.Text.StringBuilder str = new System.Text.StringBuilder();
            str.Append((char)((data & 0xFF)));
            str.Append((char)((data >> 8) & 0xFF));
            str.Append((char)((data >> 16) & 0xFF));
            str.Append((char)((data >> 24) & 0xFF));
            return str.ToString();
        }
        private void tinydecode(uint[] dat, uint[] ke)
        {
            uint data = dat[0], data1 = dat[1], delta = 2654435769, sum = delta << 5, n = 32;
            while (n-- > 0)
            {

                data1 -= (data << 4 ^ data >> 5) + data ^ sum + ke[sum >> 11 & 3];

                data -= (data1 << 4 ^ data1 >> 5) + data1 ^ sum + ke[sum & 3];
                sum -= delta;
            }
            dat[0] = data;
            dat[1] = data1;
        }
    }
}